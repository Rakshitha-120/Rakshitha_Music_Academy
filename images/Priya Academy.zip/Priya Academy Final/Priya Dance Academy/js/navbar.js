/* =====================================================
   PRIYA DARSHINI DANCE ATELIER
   UNIFIED NAVBAR JAVASCRIPT
===================================================== */

document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.getElementById("siteNavbar");
    const menuBtn = document.getElementById("siteMenuToggle");
    const nav = document.getElementById("siteNav");

    if (menuBtn && nav) {
        // Toggle mobile menu
        menuBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = nav.classList.toggle("mobile-open");
            menuBtn.classList.toggle("active", isOpen);
        });

        // Close on clicking links
        nav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                nav.classList.remove("mobile-open");
                menuBtn.classList.remove("active");
            });
        });

        // Close on clicking outside
        document.addEventListener("click", (e) => {
            if (navbar && !navbar.contains(e.target)) {
                nav.classList.remove("mobile-open");
                menuBtn.classList.remove("active");
            }
        });
    }

    // Auto-highlight active link based on current filename
    const currentPath = window.location.pathname.toLowerCase().split("/").pop() || "index.html";
    if (nav) {
        const links = nav.querySelectorAll("a");
        links.forEach((link) => {
            const href = (link.getAttribute("href") || "").toLowerCase().split("/").pop();
            if (
                href === currentPath ||
                (currentPath === "" && href === "index.html") ||
                (currentPath === "index.html" && href === "index.html")
            ) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    }
});
