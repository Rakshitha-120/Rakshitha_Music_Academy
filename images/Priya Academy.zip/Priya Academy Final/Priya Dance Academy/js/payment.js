/* =====================================================
   PAYMENT PAGE JAVASCRIPT
===================================================== */


/* =====================================================
   PAYMENT METHODS
===================================================== */

const methods = document.querySelectorAll(".method");

const paymentForms = {
    upi: document.getElementById("upiForm"),
    card: document.getElementById("cardForm"),
    netbanking: document.getElementById("netbankingForm")
};


methods.forEach(method => {

    method.addEventListener("click", () => {

        methods.forEach(item => {
            item.classList.remove("active");
        });

        method.classList.add("active");

        Object.values(paymentForms).forEach(form => {
            form.classList.remove("active-form");
        });

        const selectedMethod =
            method.dataset.method;

        paymentForms[selectedMethod]
            .classList.add("active-form");

    });

});


/* =====================================================
   CARD NUMBER FORMAT
===================================================== */

const cardNumber =
    document.getElementById("cardNumber");


if (cardNumber) {

    cardNumber.addEventListener("input", () => {

        let value =
            cardNumber.value
                .replace(/\D/g, "")
                .substring(0, 16);

        value =
            value.match(/.{1,4}/g)?.join(" ")
            || "";

        cardNumber.value = value;

    });

}


/* =====================================================
   EXPIRY FORMAT
===================================================== */

const expiry =
    document.getElementById("expiry");


if (expiry) {

    expiry.addEventListener("input", () => {

        let value =
            expiry.value
                .replace(/\D/g, "")
                .substring(0, 4);

        if (value.length > 2) {

            value =
                value.substring(0, 2)
                + "/"
                + value.substring(2);

        }

        expiry.value = value;

    });

}


/* =====================================================
   PAYMENT
===================================================== */

const payButton =
    document.getElementById("payButton");

const successOverlay =
    document.getElementById("successOverlay");


if (payButton) {

    payButton.addEventListener("click", () => {

        const activeMethod =
            document.querySelector(".method.active")
                ?.dataset.method;


        let valid = true;


        /* UPI */

        if (activeMethod === "upi") {

            const upi =
                document.getElementById("upiId").value.trim();

            if (!upi) {

                alert("Please enter your UPI ID.");

                valid = false;

            }

        }


        /* CARD */

        if (activeMethod === "card") {

            const card =
                document.getElementById("cardNumber").value.trim();

            const expiryValue =
                document.getElementById("expiry").value.trim();

            const cvv =
                document.getElementById("cvv").value.trim();


            if (!card || !expiryValue || !cvv) {

                alert("Please complete your card details.");

                valid = false;

            }

        }


        /* NET BANKING */

        if (activeMethod === "netbanking") {

            const bank =
                document.getElementById("bank").value;

            if (!bank) {

                alert("Please select your bank.");

                valid = false;

            }

        }


        if (valid) {

            successOverlay.classList.add("show");

        }

    });

}