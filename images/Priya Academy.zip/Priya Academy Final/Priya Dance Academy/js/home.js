/* =====================================================
   PRIYA DARSHINI DANCE ATELIER
   HOME PAGE JAVASCRIPT
===================================================== */

document.addEventListener("DOMContentLoaded", () => {


    /* =================================================
       BRAND INTRO
    ================================================== */

    const homeIntro = document.getElementById("homeIntro");

    if (homeIntro) {

        document.body.classList.add("intro-active");

        setTimeout(() => {

            homeIntro.classList.add("hide");

            homeIntro.setAttribute("aria-hidden", "true");

            document.body.classList.remove("intro-active");

        }, 2200);

    }


    /* =================================================
       SCROLL REVEAL
    ================================================== */

    const revealElements =
        document.querySelectorAll(".reveal");

    if ("IntersectionObserver" in window) {

        const observer =
            new IntersectionObserver(
                (entries, obs) => {

                    entries.forEach((entry) => {

                        if (entry.isIntersecting) {

                            entry.target.classList.add("show");

                            obs.unobserve(entry.target);

                        }

                    });

                },
                {
                    threshold: 0.12,
                    rootMargin: "0px 0px -40px 0px"
                }
            );

        revealElements.forEach((element) => {

            observer.observe(element);

        });

    } else {

        revealElements.forEach((element) => {

            element.classList.add("show");

        });

    }

});