/* =====================================================
   DANCE STYLE POPUP
===================================================== */

function showDance(title, description) {

    const existing = document.querySelector(".dance-popup");

    if (existing) {
        existing.remove();
    }


    const popup = document.createElement("div");

    popup.className = "dance-popup";


    popup.innerHTML = `

        <div class="popup-box">

            <button class="popup-close"
                onclick="this.closest('.dance-popup').remove()">
                ×
            </button>

            <span>DISCOVER THE STYLE</span>

            <h2>${title}</h2>

            <p>${description}</p>

            <a href="programs.html">
                Explore Programs →
            </a>

        </div>

    `;


    document.body.appendChild(popup);


    requestAnimationFrame(() => {

        popup.classList.add("visible");

    });

}


/* =====================================================
   FIND YOUR DANCE
===================================================== */

function findDance(type) {

    const title =
        document.getElementById("resultTitle");

    const text =
        document.getElementById("resultText");

    const result =
        document.getElementById("finderResult");


    const matches = {

        classical: {

            title: "Bharatanatyam",

            text:
                "Discipline, rhythm and timeless classical expression."

        },


        freedom: {

            title: "Contemporary",

            text:
                "Freedom, flow and emotion through expressive movement."

        },


        performance: {

            title: "Bollywood",

            text:
                "Energy, expression and the joy of performing."

        },


        story: {

            title: "Kuchipudi",

            text:
                "Graceful movement combined with rhythm and storytelling."

        }

    };


    const selected = matches[type];


    if (!selected) {
        return;
    }


    title.textContent =
        selected.title;


    text.textContent =
        selected.text;


    result.classList.add("show");

}





/* =====================================================
   POPUP STYLES
===================================================== */

const popupStyles = document.createElement("style");

popupStyles.textContent = `

.dance-popup {

    position: fixed;

    inset: 0;

    z-index: 9999;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 25px;

    background: rgba(10,15,25,.75);

    backdrop-filter: blur(8px);

    opacity: 0;

    transition: opacity .3s ease;

}


.dance-popup.visible {

    opacity: 1;

}


.popup-box {

    position: relative;

    width: min(500px, 100%);

    padding: 55px;

    background: #f7f4ee;

    color: #111827;

    box-shadow: 0 30px 80px rgba(0,0,0,.35);

    transform: translateY(25px);

    transition: transform .4s ease;

}


.dance-popup.visible .popup-box {

    transform: translateY(0);

}


.popup-box > span {

    color: #c9a96e;

    font-size: 9px;

    letter-spacing: 3px;

}


.popup-box h2 {

    margin-top: 15px;

    font-family: "Cormorant Garamond", serif;

    font-size: 55px;

    font-weight: 500;

}


.popup-box p {

    margin: 20px 0 30px;

    color: #737984;

    line-height: 1.8;

    font-size: 13px;

}


.popup-box a {

    display: inline-block;

    padding: 14px 20px;

    background: #111827;

    color: #dfc28d;

    font-size: 9px;

    letter-spacing: 2px;

    text-transform: uppercase;

}


.popup-close {

    position: absolute;

    top: 18px;

    right: 22px;

    border: 0;

    background: none;

    color: #111827;

    font-size: 28px;

    cursor: pointer;

}

`;

document.head.appendChild(popupStyles);