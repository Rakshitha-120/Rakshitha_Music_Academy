/* =====================================================
   BILLING SWITCH
===================================================== */

const billingOptions =
    document.querySelectorAll(
        ".billing-option"
    );


const prices =
    document.querySelectorAll(
        ".price"
    );


billingOptions.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            const period =
                button.dataset.period;


            billingOptions.forEach(
                option => {

                    option.classList.remove(
                        "active"
                    );

                }
            );


            button.classList.add(
                "active"
            );


            prices.forEach(price => {

                const newPrice =
                    price.dataset[period];


                price.textContent =
                    Number(newPrice).toLocaleString(
                        "en-IN"
                    );

            });

        }
    );

});


/* =====================================================
   SCROLL REVEAL
===================================================== */

const revealElements =
    document.querySelectorAll(".reveal");


if (revealElements.length) {

    const revealObserver =
        new IntersectionObserver(

            entries => {

                entries.forEach(entry => {

                    if (
                        entry.isIntersecting
                    ) {

                        entry.target.classList.add(
                            "show"
                        );


                        revealObserver.unobserve(
                            entry.target
                        );

                    }

                });

            },

            {
                threshold: 0.12
            }

        );


    revealElements.forEach(
        element => {

            revealObserver.observe(
                element
            );

        }
    );

}


/* =====================================================
   PLAN URL HANDLING
===================================================== */

const planLinks =
    document.querySelectorAll(
        ".plan-action"
    );


planLinks.forEach(link => {

    link.addEventListener(
        "click",
        () => {

            const url =
                new URL(
                    link.href,
                    window.location.href
                );


            const selectedPlan =
                url.searchParams.get(
                    "plan"
                );


            if (selectedPlan) {

                sessionStorage.setItem(
                    "selectedDancePlan",
                    selectedPlan
                );

            }

        }
    );

});


/* =====================================================
   SMOOTH PLAN SCROLL
===================================================== */

const heroLink =
    document.querySelector(
        ".hero-link"
    );


if (heroLink) {

    heroLink.addEventListener(
        "click",
        event => {

            event.preventDefault();


            const target =
                document.getElementById(
                    "plans"
                );


            if (target) {

                target.scrollIntoView({
                    behavior: "smooth"
                });

            }

        }
    );

}