/* =====================================================
   MINIMUM DATE
===================================================== */

const classDate = document.getElementById("classDate");

if (classDate) {

    const today = new Date();

    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    classDate.min = `${year}-${month}-${day}`;

}


/* =====================================================
   BOOKING FORM
===================================================== */

const bookingForm = document.getElementById("bookingForm");
const formMessage = document.getElementById("formMessage");

if (bookingForm) {

    bookingForm.addEventListener("submit", function (event) {

        event.preventDefault();


        /* BASIC VALIDATION */

        const phone = document.getElementById("phone").value.trim();
        const age = document.getElementById("age").value.trim();

        const phonePattern = /^[0-9]{10}$/;

        if (!phonePattern.test(phone)) {

            formMessage.textContent =
                "Please enter a valid 10-digit phone number.";

            formMessage.style.color = "#a34d4d";

            document.getElementById("phone").focus();

            return;

        }


        if (age < 5 || age > 100) {

            formMessage.textContent =
                "Please enter a valid age.";

            formMessage.style.color = "#a34d4d";

            document.getElementById("age").focus();

            return;

        }


        /* SUCCESS MESSAGE */

        formMessage.textContent =
            "Your booking request has been submitted successfully. We will contact you shortly.";

        formMessage.style.color = "#557a61";


        /* RESET FORM */

        bookingForm.reset();


        /* RESTORE MINIMUM DATE */

        if (classDate) {

            const today = new Date();

            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, "0");
            const day = String(today.getDate()).padStart(2, "0");

            classDate.min = `${year}-${month}-${day}`;

        }

    });

}
