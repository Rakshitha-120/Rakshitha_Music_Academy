/* =====================================================
   GALLERY DATA
===================================================== */

const galleryData = {

    bharatanatyam: {
        category: "CLASSICAL DANCE",
        title: "Bharatanatyam",
        items: [
            {
                name: "Bharatanatyam Solo Recital",
                description: "Exquisite classical Bharatanatyam recital in traditional blue silk saree with gold temple adornments.",
                image: "../images/bharatanatyam_blue.jpg"
            },
            {
                name: "Synchronized Duo Recital",
                description: "Synchronized Bharatanatyam mudra gestures in vibrant red and gold silk attire in temple courtyard.",
                image: "../images/bharatanatyam_duo.jpg"
            },
            {
                name: "Grand Group Ensemble",
                description: "Harmonious crescent formation of Bharatanatyam dancers in traditional green and gold silk sarees.",
                image: "../images/bharatanatyam_group.jpg"
            }
        ]
    },

    kuchipudi: {
        category: "KUCHIPUDI DANCE",
        title: "Kuchipudi",
        items: [
            {
                name: "Kuchipudi Solo Recital",
                description: "Exquisite classical Kuchipudi posture in vibrant yellow and magenta silk saree with gold temple adornments.",
                image: "../images/bharatanatyam_yellow.jpg"
            },
            {
                name: "Tarangam Brass Plate Balance",
                description: "Graceful Kuchipudi Tarangam dance balancing on traditional polished brass plate in temple hall.",
                image: "../images/kuchipudi_tarangam.jpg"
            },
            {
                name: "Group Kuchipudi Ensemble",
                description: "Synchronized group Kuchipudi performance in royal purple and gold silk sarees with brass oil lamps.",
                image: "../images/kuchipudi_group.jpg"
            }
        ]
    },

    kathak: {
        category: "CONTEMPORARY DANCE",
        title: "Contemporary",
        items: [
            {
                name: "Kinetic Expression Solo",
                description: "Dynamic contemporary movement explosion suspended in dramatic lighting.",
                image: "../images/gallery_cover_3.jpg"
            },
            {
                name: "Emotional Partner Lift",
                description: "Fluid contemporary duo partnering capturing vulnerability, weight transfer, and momentum.",
                image: "../images/contemporary_duo_lift.jpg"
            },
            {
                name: "Grounded Floorwork Extension",
                description: "Athletic floorwork extension exploring grounded balance and spatial dynamics in studio spotlight.",
                image: "../images/contemporary_floorwork.jpg"
            }
        ]
    },

    contemporary: {
        category: "CLASSICAL DANCE",
        title: "Kathak Group Recital",
        items: [
            {
                name: "Kathak Group Spinning Recital",
                description: "Ensemble of Kathak dancers in traditional white and red Anarkali costumes performing synchronized spins on stage.",
                image: "../images/gallery_cover_4_kathak.jpg"
            },
            {
                name: "Kathak Solo Recital",
                description: "Expressive Kathak solo performance showcasing graceful hand gestures and elegant posture.",
                image: "../images/kathak_solo_new.jpg"
            },
            {
                name: "Kathak Duo Performance",
                description: "Synchronized Kathak duo performance in elegant traditional white and red attire.",
                image: "../images/kathak_duo_new.jpg"
            }
        ]
    },

    bollywood: {
        category: "WESTERN DANCE",
        title: "Jazz & Western Group",
        items: [
            {
                name: "Jazz & Western Group Ensemble",
                description: "High-energy Western and Jazz group performance under theatrical stage spotlights – Dance Unleashed.",
                image: "../images/gallery_cover_5_jazz.jpg"
            },
            {
                name: "Synchronized Stage Leaps",
                description: "Electrifying synchronized mid-air group leaps under red and blue concert spotlights.",
                image: "../images/jazz_group_leap.jpg"
            },
            {
                name: "Auditorium Crew Showcase",
                description: "Precision Western and Jazz group lineup routine executed on stage in front of a live audience.",
                image: "../images/jazz_crew_lineup.jpg"
            }
        ]
    },

    jazz: {
        category: "BOLLYWOOD DANCE",
        title: "Bollywood Style",
        items: [
            {
                name: "Bollywood Duet Performance",
                description: "Vibrant cinematic Bollywood duet dance posture performed under dramatic stage lights.",
                image: "../images/gallery_cover_6_duo.jpg"
            },
            {
                name: "Festive Group Celebration",
                description: "Joyful celebration of traditional regional Bollywood rhythms, colors, and festive energy.",
                image: "../images/bollywood_festive_group.jpg"
            },
            {
                name: "Cinematic Solo Showcase",
                description: "Expressive solo performer commanding the stage in ornate red and gold lehenga choli.",
                image: "../images/bollywood_cinematic_solo.jpg"
            }
        ]
    },

    interior: {
        category: "THE ATELIER",
        title: "Atelier Architecture",
        items: [
            {
                name: "Priya Darshini Dance Atelier",
                description: "Grand architectural facade of Priya Darshini Dance Atelier beautifully illuminated at dusk.",
                image: "../images/gallery_cover_7_atelier.jpg"
            },
            {
                name: "Atelier Grand Lobby",
                description: "Luxurious reception and grand lobby of Priya Darshini Dance Atelier.",
                image: "../images/atelier_interior_1.png"
            },
            {
                name: "Mirrored Dance Studio",
                description: "Spacious state-of-the-art mirrored dance studio with warm wooden flooring.",
                image: "../images/atelier_interior_2.png"
            }
        ]
    },

    faculty: {
        category: "REHEARSAL STUDIO",
        title: "Practice Hall",
        items: [
            {
                name: "Priya Darshini Rehearsal Studio",
                description: "Spacious mirrored practice studio with sprung wooden floor and barre practice area.",
                image: "../images/gallery_cover_8_studio.jpg"
            },
            {
                name: "Group Dance Practice",
                description: "Students performing synchronized dance movements in the spacious practice hall.",
                image: "../images/practice_hall_group.jpg"
            },
            {
                name: "Instructor Led Session",
                description: "Experienced instructor guiding students through dance techniques in the studio.",
                image: "../images/practice_hall_instructor.jpg"
            }
        ]
    }

};


/* =====================================================
   ELEMENTS
===================================================== */

const collectionCards =
    document.querySelectorAll(".collection-card");

const collectionModal =
    document.getElementById("collectionModal");

const modalGallery =
    document.getElementById("modalGallery");

const modalCategory =
    document.getElementById("modalCategory");

const modalTitle =
    document.getElementById("modalTitle");

const modalCount =
    document.getElementById("modalCount");

const modalClose =
    document.getElementById("modalClose");


const lightbox =
    document.getElementById("lightbox");

const lightboxClose =
    document.getElementById("lightboxClose");

const lightboxPrev =
    document.getElementById("lightboxPrev");

const lightboxNext =
    document.getElementById("lightboxNext");

const lightboxIndex =
    document.getElementById("lightboxIndex");

const lightboxName =
    document.getElementById("lightboxName");

const lightboxBadge =
    document.getElementById("lightboxBadge");

const lightboxTitle =
    document.getElementById("lightboxTitle");

const lightboxDesc =
    document.getElementById("lightboxDesc");


let currentCollection = null;

let currentImageIndex = 0;


/* =====================================================
   OPEN COLLECTION
===================================================== */

function openCollection(collectionName) {

    const collection =
        galleryData[collectionName];

    if (!collection) return;


    currentCollection =
        collection;


    modalCategory.textContent =
        collection.category;


    modalTitle.textContent =
        collection.title;


    modalCount.textContent =
        `${collection.items.length} MOMENTS`;


    modalGallery.innerHTML = "";


    collection.items.forEach(
        (item, index) => {

            const card =
                document.createElement("div");

            card.className =
                "modal-photo modal-image-card";

            card.style.backgroundImage =
                `linear-gradient(180deg, rgba(9, 10, 13, 0) 0%, rgba(9, 10, 13, 0.4) 100%), url('${item.image}')`;
            card.style.backgroundSize =
                "cover";
            card.style.backgroundPosition =
                "center 15%";
            card.style.filter =
                "contrast(1.15) brightness(1.15) saturate(1.2)";

            card.innerHTML = `
                <div class="modal-card-inner">
                    <span class="modal-card-num">${String(index + 1).padStart(2, "0")}</span>
                    <h4>${item.name}</h4>
                    <p>${item.description}</p>
                </div>
            `;

            card.addEventListener(
                "click",
                () => {

                    openLightbox(index);

                }
            );


            modalGallery.appendChild(card);

        }
    );


    collectionModal.classList.add("open");

    collectionModal.setAttribute(
        "aria-hidden",
        "false"
    );


    document.body.classList.add(
        "modal-open"
    );

}


/* =====================================================
   COLLECTION CARD CLICK
===================================================== */

collectionCards.forEach(card => {

    card.addEventListener(
        "click",
        () => {

            const galleryName =
                card.dataset.gallery;

            openCollection(
                galleryName
            );

        }
    );

});


/* =====================================================
   CLOSE COLLECTION
===================================================== */

function closeCollection() {

    collectionModal.classList.remove(
        "open"
    );

    collectionModal.setAttribute(
        "aria-hidden",
        "true"
    );


    document.body.classList.remove(
        "modal-open"
    );

}


modalClose.addEventListener(
    "click",
    closeCollection
);


/* =====================================================
   LIGHTBOX
===================================================== */

function openLightbox(index) {

    if (!currentCollection) return;


    currentImageIndex =
        index;


    updateLightbox();


    lightbox.classList.add(
        "open"
    );


    lightbox.setAttribute(
        "aria-hidden",
        "false"
    );

}


function updateLightbox() {

    const item =
        currentCollection.items[
            currentImageIndex
        ];

    const lightboxImg = document.getElementById("lightboxImg");
    if (lightboxImg) {
        lightboxImg.src = item.image;
        lightboxImg.alt = item.name;
    }

    if (lightboxTitle) lightboxTitle.textContent = item.name;
    if (lightboxDesc) lightboxDesc.textContent = item.description;
    if (lightboxBadge) lightboxBadge.textContent = currentCollection.category;
    if (lightboxName) lightboxName.textContent = item.name;

    if (lightboxIndex) {
        lightboxIndex.textContent =
            `${String(currentImageIndex + 1).padStart(2, "0")} / ${String(currentCollection.items.length).padStart(2, "0")}`;
    }

}


/* =====================================================
   NEXT IMAGE
===================================================== */

function nextImage() {

    if (!currentCollection) return;


    currentImageIndex++;

    if (
        currentImageIndex >=
        currentCollection.items.length
    ) {

        currentImageIndex = 0;

    }


    updateLightbox();

}


/* =====================================================
   PREVIOUS IMAGE
===================================================== */

function previousImage() {

    if (!currentCollection) return;


    currentImageIndex--;

    if (currentImageIndex < 0) {

        currentImageIndex =
            currentCollection.items.length - 1;

    }


    updateLightbox();

}


lightboxNext.addEventListener(
    "click",
    nextImage
);


lightboxPrev.addEventListener(
    "click",
    previousImage
);


/* =====================================================
   CLOSE LIGHTBOX
===================================================== */

function closeLightbox() {

    lightbox.classList.remove(
        "open"
    );

    lightbox.setAttribute(
        "aria-hidden",
        "true"
    );

}


lightboxClose.addEventListener(
    "click",
    closeLightbox
);


/* =====================================================
   KEYBOARD CONTROLS
===================================================== */

document.addEventListener(
    "keydown",
    event => {

        if (
            !lightbox.classList.contains("open")
        ) {

            if (
                event.key === "Escape" &&
                collectionModal.classList.contains("open")
            ) {

                closeCollection();

            }

            return;

        }


        if (event.key === "ArrowRight") {

            nextImage();

        }


        if (event.key === "ArrowLeft") {

            previousImage();

        }


        if (event.key === "Escape") {

            closeLightbox();

        }

    }
);


/* =====================================================
   CLICK OUTSIDE LIGHTBOX
===================================================== */

lightbox.addEventListener(
    "click",
    event => {

        if (
            event.target === lightbox
        ) {

            closeLightbox();

        }

    }
);


/* =====================================================
   SCROLL REVEAL
===================================================== */

const revealElements =
    document.querySelectorAll(".reveal");


if (revealElements.length) {

    const observer =
        new IntersectionObserver(

            entries => {

                entries.forEach(entry => {

                    if (
                        entry.isIntersecting
                    ) {

                        entry.target.classList.add(
                            "show"
                        );


                        observer.unobserve(
                            entry.target
                        );

                    }

                });

            },

            {
                threshold: 0.12
            }

        );


    revealElements.forEach(
        element => {

            observer.observe(element);

        }
    );

}