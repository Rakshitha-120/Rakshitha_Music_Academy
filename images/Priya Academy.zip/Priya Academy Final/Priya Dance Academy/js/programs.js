/* =====================================================
   PROGRAM FILTER
===================================================== */

const filterButtons =
    document.querySelectorAll(".filter-button");

const programCards =
    document.querySelectorAll(".program-card");


filterButtons.forEach(button => {

    button.addEventListener("click", () => {

        const selected =
            button.dataset.filter;


        filterButtons.forEach(item => {

            item.classList.remove("active");

        });


        button.classList.add("active");


        programCards.forEach(card => {

            const category =
                card.dataset.category;


            if (
                selected === "all" ||
                category === selected
            ) {

                card.classList.remove("hidden");

            } else {

                card.classList.add("hidden");

            }

        });

    });

});


/* =====================================================
   SCROLL REVEAL
===================================================== */

const revealElements =
    document.querySelectorAll(".reveal");


if (revealElements.length) {

    const revealObserver =
        new IntersectionObserver(

            entries => {

                entries.forEach(entry => {

                    if (entry.isIntersecting) {

                        entry.target.classList.add("show");

                        revealObserver.unobserve(
                            entry.target
                        );

                    }

                });

            },

            {
                threshold: 0.12
            }

        );


    revealElements.forEach(element => {

        revealObserver.observe(element);

    });

}